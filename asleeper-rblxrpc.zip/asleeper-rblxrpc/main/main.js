/*

    ==Roblox RPC==
    By: Cosmental

    About: Ropresence is a Roblox game tracker that works for the client it is installed on. This tracker allows discord to enrich your Roblox presence and display it to everyone
    on Discord! [This resource depends on DiscordRPC and Axios]

    ==Asleeper RBLX-RPC==
    Modified by asleeper for bug fixes, additional features and flexibility

*/

// Modules
const DiscordRPC = require('discord-rpc');
const axios = require(`axios`);

const settings = require(`./configuration.json`);

// Constants
const RobloxCookie = settings.ROBLOSECURITY // Our ROBLOSECURITY cookie will allow us to make API calls!

const clientId = settings.AppClientID // This is the OAuth2-ID of our RPC application on the Discord Developer Portal website
const API_UPDATE_QUERY = 1 // This determines how much time (in seconds) we are allowed to make calls to the roblox API endpoint

const RPC = new DiscordRPC.Client({ transport : "ipc" });

// States
var previousPlaceId

var applicationStartTime
var previousUniverse
var previousPresence

var RobloxUsername
var RobloxUserID
var RobloxThumbnailURL
var thumbnailURLID

// Main

axios.get('https://www.roblox.com/mobileapi/userinfo', { // ROBLOSECURITY Validation
    "headers": {
        "Cookie": `.ROBLOSECURITY=${RobloxCookie}`
    }
}).then(result => {
    let isValidCookie = (typeof(result.data) == 'object'); // Valid cookies should return an object/table as a response header

    if (!isValidCookie) {
        throw new Error("Your .ROBLOSECURITY cookie is invalid, usually because you logged out or passed the active expiration date. Please provide your new .ROBLOSECURITY cookie.")
    };

    // RPC Login
    DiscordRPC.register(clientId);
    RobloxUsername = result.data.UserName || "Invalid User"
    RobloxUserID = result.data.UserID || 1
    RobloxThumbnailURL = result.data.ThumbnailUrl || "https://tr.rbxcdn.com/4db69b7085238b92eb50048953c7dfb0/512/512/Avatar/Png"
    
    thumbnailURLID = RobloxThumbnailURL.split("/")[3]
    RobloxThumbnailURL = `https://tr.rbxcdn.com/${thumbnailURLID}/512/512/Avatar/Png`

    RPC.on('ready', async() => {
        function CheckEndpoint() {
            GetClientGamePresence(response => {
                let presenceData = response.data.userPresences[0];
                let presenceType = presenceData.userPresenceType // 0 = Offline (no action), 1 = Website (action), 2 = Playing Game (action), 3 = In Studio (action)

                // Active Presence Handling
                if (presenceType == 2) {
                    if (previousPlaceId == presenceData.placeId) return; // We dont need to update already existing info!
                    previousPlaceId = presenceData.placeId
                }
                
                if (presenceType == 1) {
                    if (previousPresence != 1) {
                        applicationStartTime = Date.now();
                    }
                    setActivity(presenceType);
                } else if (presenceType == 2) {
                    if (previousUniverse != presenceData.universeId) {
                        previousUniverse = presenceData.universeId
                        applicationStartTime = Date.now();
                    };
            
                    GetPlaceInfo(presenceData.placeId, placeInfo => {
                        GetUniverseIconURL(presenceData.universeId, universeURL => {
                            setActivity(presenceType, placeInfo, universeURL);
                        });
                    });
                } else if (presenceType == 3) {
                    if (previousPresence != 3) {
                        applicationStartTime = Date.now();
                    }
                    setActivity(presenceType);
                } else {clearCurrentActivity()}
                previousPresence = presenceType || 0
            });
        
            setTimeout(CheckEndpoint, API_UPDATE_QUERY * 1000);
        };
        
        console.log(`Asleeper RBLX-RPC is running! Username: ${RobloxUsername}`);
        CheckEndpoint();
    });

    RPC.login({ clientId }).catch(err => {
        throw new Error(`Roblox RPC Initialization Issue ${err}`);
    });
});

// Functions

// Sets our current activity using the provided parameters
async function setActivity(presenceType, placeInfo, placeIconURL) {
    if (!RPC) return;
    
    let presenceImage
    let presenceImageText
    if (presenceType == 1 || presenceType == 2) {
        presenceImageText = "Roblox"
        presenceImage = "https://lh3.googleusercontent.com/u/1/drive-viewer/AFGJ81ol5EW5B7_ZnZhD3AUbBgyKJhvTh7daPYuaogu_wQW3Umev0pzV4QYx_vship2o9LL0HWFlLPhjIUNGoOSitcOk2_zwhw=w1865-h961"
    } else if (presenceType == 3) {
        presenceImageText = "Roblox Studio"
        presenceImage = "https://lh3.googleusercontent.com/u/1/drive-viewer/AFGJ81oOObYAq8LQPuyOcEbBWfV2FyeLhxf-2RU89SemZXm777W0XQJUi90u8RKvPabVwdedUPuEEPkZzk5AHDpKm5UiA8KcUA=w1865-h961"
    }

    // We create an array to store the activity's information and provide it later on in connection
    // We're creating an array so we can easily edit elements inside of the array after it's created
    let activityArray
    if (presenceType == 1 || presenceType == 2) {
        activityArray = {
            "details": (presenceType == 2) ? `Playing: ${placeInfo.name}`: "Website",
            "startTimestamp": applicationStartTime,

            "largeImageKey": (presenceType == 2) ? placeIconURL: RobloxThumbnailURL,
            "largeImageText": (presenceType == 2) ? placeInfo.name: "Website",
            "smallImageKey": presenceImage,
            "smallImageText": presenceImageText,

            "instance": false,
            "buttons": [
                {
                    label: `Game URL 🔗`,
                    url: (presenceType == 2) ? placeInfo.url: ""
                },
                {
                    label: `${RobloxUsername} 👤`,
                    url: `https://www.roblox.com/users/${RobloxUserID}/profile`
                }
            ]
        }
    } else if (presenceType == 3) {
        activityArray = {
            "details": "Studio",
            "startTimestamp": applicationStartTime,

            "largeImageKey": (presenceType == 2) ? placeIconURL: RobloxThumbnailURL,
            "largeImageText": (presenceType == 2) ? placeInfo.name: "Studio",
            "smallImageKey": presenceImage,
            "smallImageText": presenceImageText,

            "instance": false,
            "buttons": [
                {
                    label: `${RobloxUsername} 👤`,
                    url: `https://www.roblox.com/users/${RobloxUserID}/profile`
                }
            ]
        }
    }

    if (presenceType == 1) {
        activityArray.buttons.shift();
    } else if (presenceType == 2) {
        activityArray.state = `By ${placeInfo.builder}`
    }

    if (typeof activityArray == "object") {
        RPC.setActivity(activityArray);
    } else {
        clearCurrentActivity()
    }
};

// Returns information about our client's in game presence!
function GetClientGamePresence(callback) {
    axios.post(`https://presence.roblox.com/v1/presence/users`, // Here we preferrably use axios in order to "spoof" our RobloSecurity token
        {"userIds":[RobloxUserID]},
        {
            "headers": {
                "Cookie": `.ROBLOSECURITY=${RobloxCookie}`
            }
        }
    )

    .then(callback)    
    .catch(function(err){
        throw new Error(`Presence request failed: \"${err}\"`)
    });
};

// Returns visual informaiton related to the provided universeId
function GetUniverseIconURL(universeId, callback) {
    axios.get(`https://thumbnails.roblox.com/v1/games/icons?universeIds=${universeId}&size=512x512&format=Png&isCircular=false`)
        .then(response => callback(response.data.data[0].imageUrl))    
        .catch(function(err){
            throw new Error(`Game Universe Icon request failed: \"${err.response.status}\"`);
        });
};

function GetPlaceInfo(placeId, callback) {
    axios.get(`https://games.roblox.com/v1/games/multiget-place-details?placeIds=${placeId}`, {
        "headers": {
            "Cookie": `.ROBLOSECURITY=${RobloxCookie}` // For some reason this endpoint requires roblox cookies?
        }
    })
        .then(response => callback(response.data[0]))
        .catch(function(err){
            throw new Error(`Failed to retrieve Place Info: \"${err}\"`);
        });
};

function clearCurrentActivity() {
    previousPlaceId = null
    previousUniverse = null

    RPC.clearActivity();
    return;
}